<?php
if (!defined('ABSPATH'))
    exit;
oxi_addons_user_capabilities();
/**
 * Check Import Elements 
 * Checking Admin Import Elements with Nonce
 */
$oxitype = 'oxi-addons';
if (!empty($_REQUEST['_wpnonce'])) {
    $nonce = $_REQUEST['_wpnonce'];
}

$status = get_option('oxi_addons_license_status');

/**
 * Elements Checking 
 * Elements checking with Custom Data
 */
$directory = OxiAddonsCustomData;
$DIRfiles = glob($directory . '*', GLOB_ONLYDIR);


$addonsfile = array();
foreach ($DIRfiles as $value) {
    $file = explode('/OxiAddonsCustomData/', $value);
    if (!empty($value)) {
        $addonsfile[] = $file[1];
    }
}
/**
 * Elements List
 */
$alldata = array(
    array(
        'Content Elements',
        array('accordion', 'bullet_list', 'button', 'content_boxes', 'count_down', 'drop_caps', 'heading', 'icon', 'icon_boxes', 'image_boxes', 'info_boxes', 'info_image_boxes', 'logo_showcase', 'single_image', 'team', 'testimonial', 'text_blocks')
    ),
    array(
        'Creative Elements',
        array('animated_text', 'banner', 'content_toggle', 'counter', 'dual_button', 'footer_info', 'headers', 'icon_effects', 'image_accordion', 'image_comparison', 'image_scroll', 'info_banner', 'interactive_cards', 'lightbox', 'link_effects', 'offcanvas_content', 'progress_bars', 'tooltip')
    ),
    array(
        'Dynamic Contents',
        array('audio_players', 'audio_playlist', 'carousel', 'category', 'data_table')
    ),
    array(
        'Marketing Elements',
        array('alert_box', 'google_chart', 'call_to_action', 'event_widgets', 'food_menu', 'opening_hours', 'product_boxes', 'price_table')
    ),
    array(
        'Image Effects',
        array('image_effects')
    //array('image_effects', 'creative_effects', 'square_effects', 'button_effects', 'hover_effects')
    ),
    array(
        'Social Elements',
        array('social_icons', 'social_share')
    ),
    array(
        'Form Contents',
        array('contact_form')
    ),
    array(
        'Extensions',
        array('divider', 'section_divider', 'spacer')
    ),
);

$url = $jquery = '';
/**
 * Free version File
 * Free version text file for Shortcode Addons
 */
oxi_addons_font_familly('Bree+Serif');
oxi_addons_font_familly('Source+Sans+Pro');
echo '<input type="hidden" name="oxi-addons-admin-ajax-nonce" id="oxi-addons-admin-ajax-nonce" value="' . wp_create_nonce("oxi_addons_admin_ajax_nonce") . '"/>';
echo '<input type="hidden" name="oxi-addons-admin-ajax-nonce" id="oxi-addons-admin-ajax-url" value="' . oxi_addons_admin_menu_link() . '"/>';
?>
<div class="wrap">
    <?php echo OxiAddonsAdmAdminMenu($oxitype, '', 'other');
    ?>
    <div class="oxi-addons-wrapper">  
        <?php
        $elementsnumber = 0;
        $elementshtml = '';
        foreach ($addonsfile as $value) {
            $elementsnumber++;
            $oxilink = 'admin.php?page=oxi-addons-' . str_replace('_', '-', $value);
            $elementshtml .= '<div class="oxi-addons-shortcode-import">
                                    <a target="_blank" href="' . $oxilink . '">
                                       <div class="oxi-addons-shortcode-import-top">
                                              ' . oxi_addons_admin_font_awesome('oxi-' . $value . '') . '
                                       </div>
                                    </a>
                                    <div class="oxi-addons-shortcode-import-bottom">
                                        <span>' . oxi_addons_shortcode_name_converter($value) . '</span>
                                        <input type="button" class="btn btn-outline-info btn-sm text-right OxiElementsADD" name="OxiElementsADD" OXIAddonsElements="' . $value . '" value="Delete">
                                    </div>
                                </div>';
        }
        if ($elementsnumber > 0) {
            echo '  <div class="oxi-addons-text-blocks-body-wrapper">
                        <div class="oxi-addons-text-blocks-body">
                            <div class="oxi-addons-text-blocks">
                                <div class="oxi-addons-text-blocks-heading">Installed Addons</div>
                                <div class="oxi-addons-text-blocks-border">
                                    <div class="oxi-addons-text-block-border"></div>
                                </div>
                                <div class="oxi-addons-text-blocks-content">Available (' . $elementsnumber . ')</div>
                            </div>
                        </div>
                    </div>';
            echo $elementshtml;
            echo '  <div class="oxi-addons-wrapper">
                        <div class="oxi-addons-doc-heading">
                            Available Addons
                        </div>
                    </div>';
        }


        foreach ($alldata as $value) {
            $elementshtml = '';
            $elementsnumber = 0;
            asort($value[1]);
            foreach ($value[1] as $val) {
                $valuetrue = '';
                foreach ($addonsfile as $importelements) {
                    if ($importelements == $val) {
                        $valuetrue = 'true';
                    }
                }

                if ($valuetrue != 'true') {
                    $elementsnumber++;
                    $elementshtml .= '<div class="oxi-addons-shortcode-import"  oxi-addons-search="' . $val . '" id ="' . $val . '">
                                                    <a target="_blank" href="https://www.oxilab.org/shortcode-addons-features/' . str_replace('_', '-', $val) . '">
                                                       <div class="oxi-addons-shortcode-import-top">
                                                              ' . oxi_addons_admin_font_awesome('oxi-' . $val . '') . '
                                                       </div>
                                                    </a>
                                                    <div class="oxi-addons-shortcode-import-bottom">
                                                        <span>' . oxi_addons_shortcode_name_converter($val) . '</span>
                                                        <input type="button" class="btn btn-outline-info btn-sm text-right OxiElementsADD" name="OxiElementsADD" OXIAddonsElements="' . $val . '" value="Install">
                                                    </div>
                                                </div>';
                }
            }
            if ($elementsnumber > 0) {
                echo '  <div class="oxi-addons-text-blocks-body-wrapper">
                                        <div class="oxi-addons-text-blocks-body">
                                            <div class="oxi-addons-text-blocks">
                                                <div class="oxi-addons-text-blocks-heading">' . $value[0] . '</div>
                                                <div class="oxi-addons-text-blocks-border">
                                                    <div class="oxi-addons-text-block-border"></div>
                                                </div>
                                                <div class="oxi-addons-text-blocks-content">Available (' . $elementsnumber . ')</div>
                                            </div>
                                        </div>
                                    </div>';
                echo $elementshtml;
            }
        }
        ?>
    </div>

</div>
<?php
$jquery = 'function oxiequalHeight(group) {
                    tallest = 0;
                    group.each(function () {
                        thisHeight = jQuery(this).height();
                        if (thisHeight > tallest) {
                            tallest = thisHeight;
                        }
                    });
                    group.height(tallest);
                }
                setTimeout(function () {
                    oxiequalHeight(jQuery(".oxi-addons-shortcode-import-bottom"));
                }, 500);
                jQuery(".oxi-addons-shortcode-import-bt .btn").click(function(){
                    var url = jQuery(this).attr("href"); 
                    window.open(url, "_blank");
                });';

$css = '.oxi-addons-wrapper ul.oxilab-admin-menu li a:hover,
        .oxi-addons-wrapper ul.oxilab-admin-menu li a.active{ 
            background: #7c00b5;
            position: relative;
            color: #fff;
        };';
echo OxiAddonsInlineCSSData($css, 'oxi-addons-admin');

wp_add_inline_script('oxi-addons-bootstrap-jquery', $jquery);
